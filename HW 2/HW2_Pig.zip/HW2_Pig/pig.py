from random import randint

def print_instructions():
    '''Prints the rules of the game.
    '''

    # TODO Insert your code here
    pass

def computer_move(computer_score, human_score):
    '''Has the computer roll some number of times, displays the result of each roll, and
    returns the result (either 0 or the total value of the rolls).
    Uses the given arguments to play more intelligently.
    '''

    # TODO Insert your code here
    pass

def human_move(computer_score, human_score):
    '''Repeatedly asks whether the user wants to roll again and displays the result of each roll.

    - If the user chooses to roll again, and DOES NOT roll a 6, this function adds the roll
    to the total of the rolls made during this move.
    - If the user chooses to roll again, and DOES roll a 6, the function returns 0.
    - If the user chooses not to roll again, the function returns the total of the rolls made during this move.
    '''

    # TODO Insert your code here
    pass

def is_game_over(computer_score, human_score):
    '''Returns True if either player has 50 or more, and the players are not tied,
    otherwise it returns False.
    '''

    # TODO Insert your code here
    pass

def roll():
    '''Returns a random number in the range 1 to 6, inclusive.
    '''

    # TODO Insert your code here
    pass

def ask_yes_or_no(prompt):
    '''Prints the given prompt as a question to the user, for example, "Roll again? (y/n) ".

    - If the user responds with a string whose first character is 'y' or 'Y', returns True.
    - If the user responds with a string whose first character is 'n' or 'N', returns False.
    - Any other response causes the question to be repeated until the user provides an acceptable response.
    '''

    # TODO Insert your code here
    pass

def show_current_status(computer_score, human_score):
    '''Tells the user both her current score and the computer's score, and how far
    behind (or ahead) she is, or if there is a tie.
    '''

    # TODO Insert your code here
    pass

def show_final_results(computer_score, human_score):
    '''Tells the user whether she won or lost, and by how much.
    '''

    # TODO Insert your code here
    pass

def main():

    print_instructions()

    game_running = True
    while game_running:

        #to start the game
        input('Ready to play? (press any key) ')

        #set initial scores
        human_score = 0
        computer_score = 0

        # TODO Insert the rest of code here

if __name__ == '__main__':
    main()